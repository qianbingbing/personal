# django-cms
django-cms is a Content Management System application with Django.
the F2E is based on a BootStrap template of "http://www.quackit.com/html/templates/"

[tutorials](http://www.d-roger.com)
