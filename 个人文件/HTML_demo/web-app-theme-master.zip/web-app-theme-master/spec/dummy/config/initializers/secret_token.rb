# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Dummy::Application.config.secret_token = 'a30ca79b6acc718f4bb47ef99814ed83a2cbc423932d6f99dc6c27478432adc7bab9ed35a830e00e139cac68c2064a6bde06a5836092eb66a3475077175279af'
